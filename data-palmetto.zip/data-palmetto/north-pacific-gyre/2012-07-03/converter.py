import numpy as np
import glob

for filename in glob.glob('NEN*.txt'):
    data=np.loadtxt(filename, delimiter=',')
    np.savetxt(filename.replace('.txt', '.csv'), data, fmt=['%d', '%4.5f'], delimiter=',')

