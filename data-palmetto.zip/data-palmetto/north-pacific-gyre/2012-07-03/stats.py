import matplotlib
matplotlib.use('Agg')
import sys
import time
import argparse
import pandas

parser=argparse.ArgumentParser(
        description='''Script to analyze assay machine output.
        For a given input file, this script computes the least
        abundant and most abundant protein. It also plots the
        relative abundance of all proteins.
        The statistics are put in the results/ directory
        and the plot is put in the plots/ directory.''')
parser.add_argument('--fname', type=str, help='Input file name')
args = parser.parse_args()

def make_plot(fname):
    n = 10
    data = pandas.read_csv(fname, sep=',', header=None)
    ax = data[1].plot(kind='bar', legend=False)
    ticks = ax.xaxis.get_ticklocs()
    ticklabels = [l.get_text() for l in ax.xaxis.get_ticklabels()]
    ax.xaxis.set_ticks(ticks[::n])
    ax.xaxis.set_ticklabels(ticklabels[::n])
    ax.figure.savefig('plots/'+fname.replace('.csv', '.png'))

def write_stats(fname):
    data = pandas.read_csv(fname, header=None)
    with open('results/'+fname.replace('.csv', '-results.out'), 'w') as f:
        f.write('Max: {}'.format(data.idxmax()[1]))
        f.write('\t')
        f.write('{}'.format(data.max()[1]))
        f.write('\n')
        f.write('Min: {}'.format(data.idxmin()[1]))
        f.write('\t')
        f.write('{}'.format(data.min()[1]))
        f.write('\n')

try:
    fname = args.fname
except:
    print("Error: Please provide valid filename as input")
    sys.exit(1)

write_stats(fname)
make_plot(fname)
#time.sleep(60)
