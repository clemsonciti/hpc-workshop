import sys
import time
import pandas

def make_plot(fname):
    n = 10
    data = pandas.read_csv(fname, sep=':', header=None)
    ax = data[1].plot(kind='bar', legend=False)
    ticks = ax.xaxis.get_ticklocs()
    ticklabels = [l.get_text() for l in ax.xaxis.get_ticklabels()]
    ax.xaxis.set_ticks(ticks[::n])
    ax.xaxis.set_ticklabels(ticklabels[::n])
    ax.figure.savefig('plots/'+fname.replace('.txt', '.png'))

def write_stats(fname):
    data = pandas.read_csv(fname, sep=':', header=None)
    with open('results/'+fname.replace('.txt', '-results.txt'), 'w') as f:
        f.write('{}'.format(data.idxmax()[1]))
        f.write('\t')
        f.write('{}'.format(data.max()[1]))
        f.write('\n')
        f.write('{}'.format(data.idxmin()[1]))
        f.write('\t')
        f.write('{}'.format(data.min()[1]))
        f.write('\n')

try:
    fname = sys.argv[1]
except:
    print("Error: Please provide valid filename as input")
    sys.exit(1)

write_stats(fname)
make_plot(fname)
time.sleep(60)
